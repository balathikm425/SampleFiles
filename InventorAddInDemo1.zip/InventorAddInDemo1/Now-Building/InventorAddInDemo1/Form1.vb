﻿Imports Inventor
Imports System.IO
Imports System.Collections.Generic
Imports System.Linq

Public Class Form1
	Private ProfileID As List(Of String) = New List(Of String)({"", "P_ID_01", "P_ID_02", "P_ID_03", "P_ID_04", "P_ID_05", "P_ID_06", "P_ID_07", "P_ID_08", "P_ID_09", "P_ID_10", "P_ID_11", "P_ID_12", "P_ID_13", "P_ID_14", "P_ID_15", "P_ID_16"})
	Private ChannelID As List(Of String) = New List(Of String)({"", "C10010", "C10012", "C10015", "C10019", "C15012", "C15019", "C15024", "C20015", "C20019", "C20024", "C20024", "C25019", "C25024",
															   "C30024", "C30030", "C35030"})
	Private ChannelData As Dictionary(Of String, List(Of String))
	Private ProfileData As Dictionary(Of String, List(Of String))
	Private BuildingDesign As List(Of String)
	Private ColumnDesign As List(Of String)
	Private Sub Button1_Click(sender As Object, e As EventArgs) Handles cmdClose.Click
		Me.Close()
	End Sub

	Private Sub ComboBox1_Click(sender As Object, e As EventArgs) Handles cboProfileID.Click
		'Dim oMyParameter = ThisApplication.ActiveDocument.ComponentDefinition.Parameters.UserParameter
	End Sub
	Private Sub UpdateParameters(oOccs As ComponentOccurrences)
		Dim oOcc As ComponentOccurrence
		For Each oOcc In oOccs
			Dim ObjName As String = oOcc.Name
			If (oOcc.DefinitionDocumentType = DocumentTypeEnum.kPartDocumentObject) Then
				oOcc.Visible = True
				Dim oPartDef As PartComponentDefinition
				oPartDef = oOcc.Definition
				Dim i As Integer
				For i = 1 To oPartDef.Parameters.Count
					If oOcc.Name.Contains("BuildSkeleton") Then
						Dim UOM As String = oPartDef.Parameters.Item(i).Units
						Select Case oPartDef.Parameters.Item(i).Name
							Case "Span"
								oPartDef.Parameters.Item(i).Value = (CDbl(BuildingDesign(0).ToString) / 10)
							Case "Height"
								oPartDef.Parameters.Item(i).Value = (CDbl(BuildingDesign(1).ToString) / 10)
							Case "Length"
								oPartDef.Parameters.Item(i).Value = (CDbl(BuildingDesign(2).ToString) / 10)
							Case "Length2"
								oPartDef.Parameters.Item(i).Value = (CDbl(BuildingDesign(2).ToString) / 10)
						End Select
						'MsgBox(oOcc.Name & "," & oPartDef.Parameters.Item(i).Name & "=" & oPartDef.Parameters.Item(i).Value)
						'If oPartDef.Parameters.Item(i).Name = "Span" Then
						'	oPartDef.Parameters.Item(i).Value = 2000
						'End If
						oOcc.Visible = False
					Else
						'If oOcc.Name.Contains("Frame") Then
						Select Case True 'oPartDef.Parameters.Item(i).Name
							Case oPartDef.Parameters.Item(i).Name.Contains("COL_WIDTH")
								oPartDef.Parameters.Item(i).Value = (CDbl(ColumnDesign(1).ToString) / 10)
							'Case "Width2"
							'	oPartDef.Parameters.Item(i).Value = (CDbl(ColumnDesign(1).ToString) / 10)
							Case oPartDef.Parameters.Item(i).Name.Contains("COL_HEIGHT")
								oPartDef.Parameters.Item(i).Value = (CDbl(ColumnDesign(0).ToString) / 10)
							'Case "Length"
							'	oPartDef.Parameters.Item(i).Value = (CDbl(BuildingDesign(1).ToString) / 10)
							Case oPartDef.Parameters.Item(i).Name.Contains("LIP")
								oPartDef.Parameters.Item(i).Value = (CDbl(ColumnDesign(3).ToString) / 10)
							'Case "LIP2"
							'	oPartDef.Parameters.Item(i).Value = (CDbl(ColumnDesign(3).ToString) / 10)
							Case oPartDef.Parameters.Item(i).Name.Contains("THICKNESS") '"THICKNESS"
								oPartDef.Parameters.Item(i).Value = (CDbl(ColumnDesign(2).ToString) / 10)
								'Case "Thickness2"
								'	oPartDef.Parameters.Item(i).Value = (CDbl(ColumnDesign(2).ToString) / 10)
								'Case "Thickness3"
								'	oPartDef.Parameters.Item(i).Value = (CDbl(ColumnDesign(2).ToString) / 10)

						End Select
						'End If
					End If
				Next i
				'ElseIf (oOcc.DefinitionDocumentType = DocumentTypeEnum.kAssemblyDocumentObject) Then
				'	MsgBox(UCase(oOcc.Name))
				'	UpdateParameters(oOcc.SubOccurrences)
			ElseIf (oOcc.DefinitionDocumentType = DocumentTypeEnum.kAssemblyDocumentObject) Then
				Dim oAssyDef As AssemblyComponentDefinition = Nothing
				oAssyDef = oOcc.Definition
				UpdateParameters(oOcc.SubOccurrences)
			End If

		Next

	End Sub
	Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
		BuildingDesign = New List(Of String)({txtSpan.Text, txtHeight.Text, txtLength.Text, txtRoofPitch.Text, cboChannleID.Text})
		Dim oApp As Inventor.Application = System.Runtime.InteropServices.Marshal.GetActiveObject("Inventor.Application")
		Dim oDoc As Document = oApp.ActiveDocument
		If (oDoc.DocumentType = DocumentTypeEnum.kAssemblyDocumentObject) Then
			Dim oDef As AssemblyComponentDefinition = oDoc.ComponentDefinition
			UpdateParameters(oDef.Occurrences)
		Else
			MsgBox("Need an assembly document.")
		End If
		oDoc.Update()
		MsgBox("Update Completes")
	End Sub
	Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
		cboProfileID.Items.AddRange(ProfileID.ToArray)
		cboChannleID.Items.AddRange(ChannelID.ToArray)
		ProfileData = New Dictionary(Of String, List(Of String))
		ProfileData.Add(ProfileID(1).ToString, New List(Of String)({"9000", "4500", "8000", ChannelId(9).ToString}))
		ProfileData.Add(ProfileID(2).ToString, New List(Of String)({"10000", "5100", "10000", ChannelId(10).ToString}))
		ProfileData.Add(ProfileID(3).ToString, New List(Of String)({"10000", "5000", "18000", ChannelId(12).ToString}))
		ProfileData.Add(ProfileID(4).ToString, New List(Of String)({"10000", "4500", "10000", ChannelId(13).ToString}))
		ProfileData.Add(ProfileID(5).ToString, New List(Of String)({"13000", "5100", "14000", ChannelId(14).ToString}))
		ProfileData.Add(ProfileID(6).ToString, New List(Of String)({"13000", "4800", "18000", ChannelId(15).ToString}))
		ProfileData.Add(ProfileID(7).ToString, New List(Of String)({"13000", "4500", "13500", ChannelId(15).ToString}))
		ProfileData.Add(ProfileID(8).ToString, New List(Of String)({"15000", "5100", "18000", ChannelId(12).ToString}))
		ProfileData.Add(ProfileID(9).ToString, New List(Of String)({"15000", "5600", "18000", ChannelId(13).ToString}))
		ProfileData.Add(ProfileID(10).ToString, New List(Of String)({"15000", "5100", "18000", ChannelId(14).ToString}))
		ProfileData.Add(ProfileID(11).ToString, New List(Of String)({"18000", "5100", "22500", ChannelId(15).ToString}))
		ProfileData.Add(ProfileID(12).ToString, New List(Of String)({"9000", "4500", "10000", ChannelId(11).ToString}))
		ProfileData.Add(ProfileID(13).ToString, New List(Of String)({"18000", "5600", "24000", ChannelId(13).ToString}))
		ProfileData.Add(ProfileID(14).ToString, New List(Of String)({"18000", "5100", "22500", ChannelId(14).ToString}))
		ProfileData.Add(ProfileID(15).ToString, New List(Of String)({"20000", "5400", "27000", ChannelId(15).ToString}))
		ProfileData.Add(ProfileID(16).ToString, New List(Of String)({"20000", "6000", "28000", ChannelId(15).ToString}))
		cboProfileID.SelectedIndex = 1

		ChannelData = New Dictionary(Of String, List(Of String))
		ChannelData.Add("C10010", New List(Of String)({"102", "51", "1", "12.5"}))
		ChannelData.Add("C10012", New List(Of String)({"102", "51", "1.2", "12.5"}))
		ChannelData.Add("C10015", New List(Of String)({"102", "51", "1.5", "13.5"}))
		ChannelData.Add("C10019", New List(Of String)({"102", "51", "1.9", "14.5"}))
		ChannelData.Add("C15012", New List(Of String)({"152", "64", "1.2", "14.5"}))
		ChannelData.Add("C15015", New List(Of String)({"152", "64", "1.5", "15.5"}))
		ChannelData.Add("C15019", New List(Of String)({"152", "64", "1.9", "16.5"}))
		ChannelData.Add("C15024", New List(Of String)({"152", "64", "2.4", "18.5"}))
		ChannelData.Add("C20015", New List(Of String)({"203", "76", "1.5", "15.5"}))
		ChannelData.Add("C20019", New List(Of String)({"203", "76", "1.9", "19"}))
		ChannelData.Add("C20024", New List(Of String)({"203", "76", "2.4", "21"}))
		ChannelData.Add("C25019", New List(Of String)({"254", "76", "1.9", "18.5"}))
		ChannelData.Add("C25024", New List(Of String)({"254", "76", "2.4", "20.5"}))
		ChannelData.Add("C30024", New List(Of String)({"300", "96", "2.4", "27.5"}))
		ChannelData.Add("C30030", New List(Of String)({"300", "96", "3", "31.5"}))
		ChannelData.Add("C35030", New List(Of String)({"300", "125", "3", "30"}))
		Dim intIndex As Integer = ChannelID.IndexOf(cboChannleID.Text)
		Dim ChannelList As List(Of String) = ChannelData.Values(intIndex).ToList
		cboChannleID_SelectedIndexChanged(Nothing, Nothing)
	End Sub



	Private Sub cboProfileID_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboProfileID.SelectedIndexChanged
		txtSpan.ResetText()
		txtHeight.ResetText()
		txtLength.ResetText()
		'txtChannleID.ResetText()
		Dim ProfileDataValues As New List(Of String)
		ProfileDataValues = ProfileData(cboProfileID.Text).ToList()
		txtSpan.Text = ProfileDataValues(0).ToString
		txtHeight.Text = ProfileDataValues(1).ToString
		txtLength.Text = ProfileDataValues(2).ToString
		'txtChannleID.Text = ProfileDataValues(3).ToString
		cboChannleID.SelectedIndex = ChannelID.IndexOf(ProfileDataValues(3).ToString)


	End Sub

	Private Sub cboChannleID_SelectedIndexChanged(sender As Object, e As EventArgs) 'Handles cboChannleID.SelectedIndexChanged
		If ChannelData.Count = 0 Then
			Exit Sub
			MsgBox("STOP")
		Else
			ColumnDesign = New List(Of String)
			ColumnDesign = ChannelData(cboChannleID.Text).ToList()
			txtChannelID.Text = cboChannleID.Text
			txtChannelWidth1.Text = ColumnDesign(1).ToString
			txtChannelWidth2.Text = ColumnDesign(1).ToString
			txtChannelHeight.Text = ColumnDesign(0).ToString
			Dim intIndex As Integer = cbochannelThickness.Items.IndexOf(ColumnDesign(2).ToString)
			cbochannelThickness.SelectedIndex = intIndex
			txtChannelLength.Text = txtHeight.Text
			cboLIPLength.SelectedIndex = cboLIPLength.Items.IndexOf(ColumnDesign(3).ToString)
		End If
	End Sub
	Private Sub Form1_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
		AddHandler cboChannleID.SelectedIndexChanged, AddressOf cboChannleID_SelectedIndexChanged
	End Sub
End Class