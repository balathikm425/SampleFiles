﻿Imports System.Runtime.InteropServices
Imports Inventor
Imports Microsoft.Win32
Imports System
Imports System.IO
Module Module_CustomRibbon

    Sub defaultTest()
        MsgBox("DEFAULT TEST")
    End Sub


    '    Sub Customize_Ribbon()
    '        g_inventorApplication.SilentOperation = True
    '        'silently create file of type
    '        'set the custom ribbon panel
    '        'then close the file
    '        ' Create a new Assembly document, using the default Assembly template.
    '        Dim oAssemblyDoc As AssemblyDocument = g_inventorApplication.Documents.Add(DocumentTypeEnum.kAssemblyDocumentObject, True) ', g_inventorApplication.FileManager.GetTemplateFile(kAssemblyDocumentObject), True)
    '        SetRibbon()
    '        oAssemblyDoc.Close()

    '        ' Create a new Drawing document, using the default Drawing template.
    '        'Dim oDrawDoc As DrawingDocument = "\\SERVER\Departments\CAD\Inventor\Macros\Macro_Template.idw"
    '        'oDrawDoc = g_inventorApplication.Documents.Add(DocumentTypeEnum.kDrawingDocumentObject, sTemplate, True)
    '        SetRibbon()
    '        'oDrawDoc.Close()


    '        ' Create a new part document, using the default part template.
    '        Dim oPartDoc As PartDocument = g_inventorApplication.Documents.Add(DocumentTypeEnum.kPartDocumentObject, g_inventorApplication.FileManager.GetTemplateFile(DocumentTypeEnum.kPartDocumentObject), True)

    '        SetRibbon()
    '        oPartDoc.Close()
    '        g_inventorApplication.SilentOperation = False
    '    End Sub



    '    Sub SetRibbon()

    '        Dim oRibbon As Inventor.Ribbon
    '        Dim oType As RibbonTab
    '        'determine file type
    '        If g_inventorApplication.ActiveDocumentType = DocumentTypeEnum.kAssemblyDocumentObject Then
    '            oRibbon = g_inventorApplication.UserInterfaceManager.Ribbons.Item("Assembly")
    '            oType = "Assembly"
    '        ElseIf g_inventorApplication.ActiveDocumentType = DocumentTypeEnum.kPartDocumentObject Then
    '            oRibbon = g_inventorApplication.UserInterfaceManager.Ribbons.Item("Part")
    '            oType = "Part"
    '        ElseIf g_inventorApplication.ActiveDocumentType = DocumentTypeEnum.kDrawingDocumentObject Then
    '            oRibbon = g_inventorApplication.UserInterfaceManager.Ribbons.Item("Drawing")
    '            oType = "Drawing"
    '        Else
    '            oType = "Unknown"
    '        End If


    '        'If oType = "Unknown" Then
    '        '    Exit Sub
    '        'End If


    '        'Get the "Tools" tabs
    '        Dim oTab As RibbonTab
    '        oTab = oRibbon.RibbonTabs.Item("id_TabTools")
    '        oTab.Active = True


    '        'clean up existing custom panels
    '        'this prevents errors when panels
    '        'already exists
    '        Dim oPanel As RibbonPanel
    '        For Each oPanel In oTab.RibbonPanels
    '            If oPanel.DisplayName = "My Assembly Tools" _
    '            Or oPanel.DisplayName = "My Drawing Tools" _
    '            Or oPanel.DisplayName = "My Part Tools" Then
    '                oPanel.Delete 'remove it

    '            End If
    '        Next

    '        ' Create a panels
    '        Dim oPanel_Assem As RibbonPanel
    '        oPanel_Assem = oTab.RibbonPanels.Add("My Assembly Tools", "ToolsTabAssemPanel", "SampleClientId")
    '        Dim oPanel_Draw As RibbonPanel
    '        oPanel_Draw = oTab.RibbonPanels.Add("My Drawing Tools", "ToolsTabDrawPanel", "SampleClientId")
    '        Dim oPanel_Part As RibbonPanel
    '        oPanel_Part = oTab.RibbonPanels.Add("My Part Tools", "ToolsTabPartPanel", "SampleClientId-3")


    '        Dim oMacroDef As MacroControlDefinition

    '        If oType = "Assembly" Then

    '            oMacroDef = g_inventorApplication.CommandManager.ControlDefinitions.
    '    AddMacroControlDefinition("Module_iLogicRules.Bend Spoon Rule")

    '            oPanel_Assem.CommandControls.AddMacro oMacroDef, False

    '    Set oMacroDef = ThisApplication.CommandManager.ControlDefinitions. _
    '    AddMacroControlDefinition("Module_iLogicRules.Bend Fork Rule")

    '    oPanel_Assem.CommandControls.AddMacro oMacroDef, False

    '    Set oMacroDef = ThisApplication.CommandManager.ControlDefinitions. _
    '    AddMacroControlDefinition("Module_iLogicRules.Bend Knife Rule")

    '    oPanel_Assem.CommandControls.AddMacro oMacroDef, False

    'ElseIf oType = "Drawing" Then
    '            'add drawing rules code here

    '        ElseIf oType = "Part" Then
    '            'add part rules code here

    '        End If

    '    End Sub
End Module
