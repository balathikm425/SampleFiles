Imports System.Runtime.InteropServices
Imports Inventor
Imports Microsoft.Win32
Imports System
Imports System.IO
Imports System.Text
Imports System.Collections.Generic
Imports System.Drawing

Namespace InventorAddInDemo1
	<ProgIdAttribute("InventorAddInDemo1.StandardAddInServer"), GuidAttribute("a20f22b7-102f-4c72-9c16-206288794344")>
	Public Class StandardAddInServer
		Implements Inventor.ApplicationAddInServer

		Private WithEvents m_uiEvents As UserInterfaceEvents
		'Private WithEvents m_sampleButton As ButtonDefinition
		Private WithEvents m_sampleButton2 As ButtonDefinition
		'Private partRibbon As Ribbon
		Private assemblyRibbon As Ribbon

#Region "ApplicationAddInServer Members"
		Public Sub Activate(ByVal addInSiteObject As Inventor.ApplicationAddInSite, ByVal firstTime As Boolean) Implements Inventor.ApplicationAddInServer.Activate
			' Initialize AddIn members.
			g_inventorApplication = addInSiteObject.Application

			' Connect to the user-interface events to handle a ribbon reset.
			m_uiEvents = g_inventorApplication.UserInterfaceManager.UserInterfaceEvents
			'partRibbon = g_inventorApplication.UserInterfaceManager.Ribbons.Item("Part")
			assemblyRibbon = g_inventorApplication.UserInterfaceManager.Ribbons.Item("Assembly")
			' TODO: Add button definitions.

			' Sample to illustrate creating a button definition.
			'Dim largeIcon As stdole.IPictureDisp = PictureDispConverter.ToIPictureDisp(My.Resources.YourBigImage)
			'Dim smallIcon As stdole.IPictureDisp = PictureDispConverter.ToIPictureDisp(My.Resources.YourSmallImage)
			Dim controlDefs As Inventor.ControlDefinitions = g_inventorApplication.CommandManager.ControlDefinitions
			'm_sampleButton = controlDefs.AddButtonDefinition("Cool Tool", "CoolTool1", CommandTypesEnum.kShapeEditCmdType, AddInClientID)
			m_sampleButton2 = controlDefs.AddButtonDefinition("Open Part", "OpenPart", CommandTypesEnum.kShapeEditCmdType, AddInClientID)
			' Add to the user interface, if it's the first time.
			If firstTime Then
				AddToUserInterface()
			End If
		End Sub

		' This method is called by Inventor when the AddIn is unloaded. The AddIn will be
		' unloaded either manually by the user or when the Inventor session is terminated.
		Public Sub Deactivate() Implements Inventor.ApplicationAddInServer.Deactivate

			' TODO:  Add ApplicationAddInServer.Deactivate implementation

			' Release objects.
			m_uiEvents = Nothing
			g_inventorApplication = Nothing

			System.GC.Collect()
			System.GC.WaitForPendingFinalizers()
		End Sub

		' This property is provided to allow the AddIn to expose an API of its own to other 
		' programs. Typically, this  would be done by implementing the AddIn's API
		' interface in a class and returning that class object through this property.
		Public ReadOnly Property Automation() As Object Implements Inventor.ApplicationAddInServer.Automation
			Get
				Return Nothing
			End Get
		End Property

		' Note:this method is now obsolete, you should use the 
		' ControlDefinition functionality for implementing commands.
		Public Sub ExecuteCommand(ByVal commandID As Integer) Implements Inventor.ApplicationAddInServer.ExecuteCommand
		End Sub

#End Region

#Region "User interface definition"
		' Sub where the user-interface creation is done.  This is called when
		' the add-in loaded and also if the user interface is reset.
		Private Sub AddToUserInterface()
			' This is where you'll add code to add buttons to the ribbon.

			'** Sample to illustrate creating a button on a new panel of the Tools tab of the Part ribbon.

			'' Get the part ribbon.
			'Dim toolsTab As RibbonTab = partRibbon.RibbonTabs.Add("NOW BUILDING", "NowBuilding", "id_NowBuilding")

			'' Get the "Tools" tab.
			'Dim toolsTab As RibbonTab = partRibbon.RibbonTabs.Item("id_TabTools")
			'Dim customPanel As RibbonPanel = toolsTab.RibbonPanels.Add("Cool Tools", "CoolTool1", AddInClientID)
			'customPanel.CommandControls.AddButton(m_sampleButton)
			'customPanel.CommandControls.AddButton(m_sampleButton2)


			Dim toolsTab As RibbonTab = assemblyRibbon.RibbonTabs.Add("NOW BUILDING", "NowBuilding", "id_NowBuilding")
			Dim customPanel As RibbonPanel = toolsTab.RibbonPanels.Add("NOW BUILDING", "NOWBuilding", AddInClientID)
			'customPanel.CommandControls.AddButton(m_sampleButton)
			customPanel.CommandControls.AddButton(m_sampleButton2)
			customPanel.
			'toolsTab.Active = True
			'Dim oRibbon As Inventor.Ribbon = g_inventorApplication.UserInterfaceManager.Ribbons.Item("id_TabTools")
			'toolsTab = partRibbon.RibbonTabs.Item("id_TabTools")
			'' Create a new panel.

			'' Add a button.


			'partRibbon = g_inventorApplication.UserInterfaceManager.Ribbons.Item("Assembly")

			'' Get the "Tools" tab.



		End Sub

		Private Sub m_uiEvents_OnResetRibbonInterface(Context As NameValueMap) Handles m_uiEvents.OnResetRibbonInterface
			' The ribbon was reset, so add back the add-ins user-interface.
			AddToUserInterface()
		End Sub
		'Public Function AddCustomiPartMember(FactoryFileName, Position, FullFileName, Row, CustomInput) As ComponentOccurrence

		'End Function
		'Public Function AddiPartMember(ByVal FactoryFileName As String, ByVal Position As Matrix, Optional ByVal Row As Long = 2) As ComponentOccurrence
		'End Function

		Public Sub AddiParts()
			Dim DataFolder As String = "H:\Inventor\Now Building" '& "\Samples\Data_Files"
			'Dim standardiPartFile As String = DataFolder & "\Generic Column.ipt"
			Dim customiPartFile As String = DataFolder & "\Generic Column.ipt"
			Dim oTG As TransientGeometry = g_inventorApplication.TransientGeometry
			' Create a matrix.  A new matrix is initialized
			' with an identity matrix.
			Dim oMatrix As Matrix = oTG.CreateMatrix
			Dim oAsmDef As AssemblyComponentDefinition = g_inventorApplication.ActiveDocument.ComponentDefinition
			Dim oOcc As ComponentOccurrence
			Dim oDoc As PartDocument
			Dim oPartDef As PartComponentDefinition
			'Open the standard iPart file
			'oDoc = g_inventorApplication.Documents.Open(standardiPartFile, True)
			'oPartDef = oDoc.ComponentDefinition
			'Dim oTblRow As iPartTableRow = oPartDef.iPartFactory.TableRows.Item(2)
			''Three ways to insert Standard iPart
			'' 1. By Row index
			'oOcc = oAsmDef.Occurrences.AddiPartMember(standardiPartFile, oMatrix, 1)
			'' 2. By iPart Table Row,
			'oMatrix.SetTranslation(oTG.CreateVector(100, 0, 0))
			'oOcc = oAsmDef.Occurrences.AddiPartMember(standardiPartFile, oMatrix, oTblRow)
			'' 3. By string identifier
			'oMatrix.SetTranslation(oTG.CreateVector(200, 0, 0))
			'oOcc = oAsmDef.Occurrences.AddiPartMember(standardiPartFile, oMatrix, "StandardFactory [d0=2.2][d1=6.837][d2=2.551]")
			''close without saving any changes
			'oDoc.Close(True)
			'Open the custom iPart file
			oDoc = g_inventorApplication.Documents.Open(customiPartFile, False)
			oPartDef = oDoc.ComponentDefinition
			If oPartDef.iPartFactory.CustomFactory = True Then
				MsgBox("This is Custom iPart Factory")
			End If
			Dim oTblRowCust As iPartTableRow = oPartDef.iPartFactory.TableRows.Item(2)
			'Two ways to insert custom ipart
			'Row by index
			oMatrix.SetTranslation(oTG.CreateVector(0, 0, 0))
			oOcc = oAsmDef.Occurrences.AddCustomiPartMember(customiPartFile, oMatrix, "C:\temp\Generic Column.ipt", 2)
			' Row by string identifier
			oMatrix.SetTranslation(oTG.CreateVector(400, 0, 0))
			oOcc = oAsmDef.Occurrences.AddCustomiPartMember(customiPartFile, oMatrix, "C:\temp\Generic Column.ipt", "CustomFactory [d0=2.3][d1=6.937][d2=2.552]")
			'close without saving any changes
			oDoc.Close(True)
		End Sub
		Public Sub CreateRibbonButtonPopup()
			'Dim partRibbon As Ribbon = g_inventorApplication.UserInterfaceManager.Ribbons.Item("Part")
			'' Get the "Tools" tab.
			'Dim toolsTab As RibbonTab = partRibbon.RibbonTabs.Add("NOW BUILDING", "Part", AddInClientID)
			MsgBox("Button was clicked.Huzzah!")
			'Dim oMatrix As Matrix = oTG.CreateMatrix
			'Dim oAsmDef As AssemblyComponentDefinition = g_inventorApplication.ActiveDocument.ComponentDefinition
			'Dim oOcc As ComponentOccurrence
			'Dim oDoc As PartDocument
			'Dim oPartDef As PartComponentDefinition
			'Dim customiPartFile As String = "\Generic Column.ipt"
			'oOcc = oAsmDef.Occurrences.AddCustomiPartMember(customiPartFile, oMatrix, "C:\temp\Generic Column.ipt", 2)
			'Dim uiMan As UserInterfaceManager = g_inventorApplication.UserInterfaceManager
			'If uiMan.InterfaceStyle = InterfaceStyleEnum.kRibbonInterface Then
			'	Dim tab As RibbonTab = GetSetRibbonTab("Presentation", "INAW", Nothing)
			'	Dim panel As RibbonPanel = GetSetRibbonPanel(tab, "INAW Panel06", Nothing)

			'	Dim icon As New Icon(Me.[GetType](), "addin.ico")
			'	' ICO embedded
			'	Dim button1 As New InventorButton("Button 1", "INAW.InventorAddin.Presentation_INAW_INAWPanel06_BigButton1", "Button 1 description", "Button 1 tooltip", icon, icon,
			'	CommandTypesEnum.kShapeEditCmdType, ButtonDisplayEnum.kDisplayTextInLearningMode)
			'	button1.Execute = Function() MessageBox.Show("Hi, I'm BigButton1.")
			'	' lambda expression.
			'	Dim button2 As New InventorButton("Button 2", "INAW.InventorAddin.Presentation_INAW_INAWPanel06_BigButton2", "Button 2 description", "Button 2 tooltip", icon, icon,
			'	CommandTypesEnum.kEditMaskCmdType, ButtonDisplayEnum.kAlwaysDisplayText)
			'	button2.Execute = Function() MessageBox.Show("Hi, I'm BigButton2.")

			'	Dim button3 As New InventorButton("Button 3", "INAW.InventorAddin.Presentation_INAW_INAWPanel06_BigButton3", "Button 3 description", "Button 3 tooltip", icon, icon,
			'	CommandTypesEnum.kEditMaskCmdType, ButtonDisplayEnum.kAlwaysDisplayText)
			'	button3.Execute = Function() MessageBox.Show("Hi, I'm BigButton3.")

			'	Dim controls As ObjectCollection = g_inventorApplication.TransientObjects.CreateObjectCollection()
			'	controls.Add(button1.ButtonDef)
			'	controls.Add(button2.ButtonDef)
			'	controls.Add(button3.ButtonDef)

			'	Dim cmdCtrls As CommandControls = panel.CommandControls
			'	cmdCtrls.AddButtonPopup(controls, True, True, "", False)
			'End If
		End Sub
		Public Sub PrintRibbon()
			Dim userInterfaceManager As UserInterfaceManager = g_inventorApplication.UserInterfaceManager
			Using sw As New StreamWriter("H:\Inventor\InventorRibbonPanels.txt")
				For Each ribbon As Inventor.Ribbon In userInterfaceManager.Ribbons
					sw.WriteLine(String.Format("{0}", ribbon.InternalName))
					For Each tab As Inventor.RibbonTab In ribbon.RibbonTabs
						sw.WriteLine(String.Format(vbTab & "{0} - {1}", tab.DisplayName, tab.InternalName))
						For Each panel As Inventor.RibbonPanel In tab.RibbonPanels
							sw.WriteLine(String.Format(vbTab & vbTab & "{0} - {1}", panel.DisplayName, panel.InternalName))
						Next
					Next
				Next
				sw.Close()
			End Using
		End Sub
		Private Sub AccessParametersFromAssembly()

			Dim oApp As Inventor.Application = System.Runtime.InteropServices.Marshal.GetActiveObject("Inventor.Application")
			Dim oDoc As Document = oApp.ActiveDocument
			If (oDoc.DocumentType = DocumentTypeEnum.kAssemblyDocumentObject) Then
				MsgBox(oDoc.DisplayName)
				Dim oDef As AssemblyComponentDefinition = oDoc.ComponentDefinition
				PrintParameters(oDef.Occurrences)
			Else
				MsgBox("Need an assembly document.")
			End If
			oDoc.Update()
		End Sub



		Private Sub PrintParameters(oOccs As ComponentOccurrences)
			Dim oOcc As ComponentOccurrence
			For Each oOcc In oOccs

				If (oOcc.DefinitionDocumentType = DocumentTypeEnum.kPartDocumentObject) Then
					Dim oPartDef As PartComponentDefinition
					oPartDef = oOcc.Definition
					Dim i As Integer
					For i = 1 To oPartDef.Parameters.Count
						If oOcc.Name.Contains("Part2") Then
							Dim UOM As String = oPartDef.Parameters.Item(i).Units
							MsgBox(oOcc.Name & "," & oPartDef.Parameters.Item(i).Name & "=" & oPartDef.Parameters.Item(i).Value)
							If oPartDef.Parameters.Item(i).Name = "Span" Then
								oPartDef.Parameters.Item(i).Value = 2000
							End If
						End If
					Next i
				ElseIf (oOcc.DefinitionDocumentType = DocumentTypeEnum.kAssemblyDocumentObject) Then
					MsgBox(UCase(oOcc.Name))

					PrintParameters(oOcc.SubOccurrences)

				End If

			Next

		End Sub
		Public Sub PopulateIparts()
			AccessParametersFromAssembly()
			'Dim oAsmDoc As AssemblyDocument = g_inventorApplication.ActiveDocument
			'Dim oAsmDef As AssemblyComponentDefinition = oAsmDoc.ComponentDefinition
			'Dim oDocCount As Integer = g_inventorApplication.Documents.Count
			'For i = 1 To oDocCount
			'	Dim oDoc As Document = g_inventorApplication.Documents.Item(i)
			'	If oDoc.FullFileName.Contains("Part2") Then
			'		Dim setDoc As Document = g_inventorApplication.Documents.ItemByName(oDoc.FullFileName)
			'		'Dim oOccs As ComponentOccurrencesEnumerator = oAsmDef.Occurrences.AllReferencedOccurrences(oDoc)
			'		Dim allParams As Parameters = setDoc.ActivatedObject. 'oAsmDoc.ComponentDefinition.Parameters
			'		'oParas = allParams.UserParameters
			'		MsgBox(oDoc.File)

			'	End If

			'Next
		End Sub
		Public Sub FindOccurrences()
			' Get the active assembly.
			Dim oAsmDoc As AssemblyDocument = g_inventorApplication.ActiveDocument
			' Get the definition of the assembly.
			Dim oAsmDef As AssemblyComponentDefinition = oAsmDoc.ComponentDefinition
			' Get the document to find occurrences for. Since it�s assumed
			' there is at least one occurrence in the assembly that 
			' references this document, it will already be open since it
			' was opened when the assembly was opened.
			Dim oDoc As Document = g_inventorApplication.Documents.ItemByName("H:\Inventor\MyViceWithConstrains\Generic Column.ipt")
			' Get the occurrences that represent this document.
			Dim oOccs As ComponentOccurrencesEnumerator = oAsmDef.Occurrences.AllReferencedOccurrences(oDoc)
			' Print the occurrences to the Immediate window.
			Dim oOcc As ComponentOccurrence
			For Each oOcc In oOccs
				MsgBox(oOcc.Name)
			Next
		End Sub

		Public Sub RetrieveFaceFromFactory()
			' Get the active assembly.
			Dim oAsmDoc As AssemblyDocument = g_inventorApplication.ActiveDocument
			' Get the assembly component definition.
			Dim oAsmDef As AssemblyComponentDefinition = oAsmDoc.ComponentDefinition
			' Get all of the leaf occurrences of the assembly.
			Dim oLeafOccs As ComponentOccurrencesEnumerator = oAsmDef.Occurrences.AllLeafOccurrences
			' Iterate through the occurrences and print the name.
			Dim oOcc As ComponentOccurrence
			For Each oOcc In oLeafOccs
				MsgBox(oOcc.Name)
			Next
			MsgBox("STOP")
			'Dim oFacePx As FaceProxy = oAsmDoc.SelectSet.Item(0)
			'Dim oOcc As ComponentOccurrence = oAsmDoc.ComponentDefinition.Occurrences.Item(1)
			'Dim oFacePxIterator As FaceProxy
			'Dim FaceIndex As Long
			'FaceIndex = 1
			'For Each oFacePxIterator In oOcc.SurfaceBodies.Item(1).Faces
			'	If oFacePxIterator Is oFacePx Then
			'		Exit For
			'	End If
			'	FaceIndex = FaceIndex + 1
			'Next
			'Dim oPartDef As PartComponentDefinition
			'oPartDef = oOcc.Definition
			'Dim oFactoryDoc As PartDocument
			'oFactoryDoc = oPartDef.iPartMember.ParentFactory.Parent
			'Dim oNativeFace As Face
			'oNativeFace = oFactoryDoc.ComponentDefinition.SurfaceBodies.Item(1).Faces(FaceIndex)
			'Dim oAttributeSet As AttributeSet
			'For Each oAttributeSet In oNativeFace.AttributeSets
			'	Dim oAttribute As Inventor.Attribute
			'	For Each oAttribute In oAttributeSet
			'		MsgBox(".Attribute Name: " & oAttribute.Name)
			'		MsgBox(".Attribute Value: " & oAttribute.Value & vbCrLf)
			'	Next
			'Next
		End Sub

		Public Sub CopyFaceAttributes()
			Dim oAsmDoc As AssemblyDocument = g_inventorApplication.ActiveDocument
			Dim oOcc As ComponentOccurrence
			oOcc = oAsmDoc.ComponentDefinition.Occurrences.Item(1)
			Dim oOccFaces As Faces
			oOccFaces = oOcc.SurfaceBodies.Item(1).Faces
			Dim oFactoryDoc As PartDocument
			oFactoryDoc = oOcc.Definition.iPartMember.ParentFactory.Parent
			Dim oNativeFaces As Faces
			oNativeFaces = oFactoryDoc.ComponentDefinition.SurfaceBodies.Item(1).Faces
			Dim i As Long
			For i = 1 To oNativeFaces.Count
				Dim oFacePx As FaceProxy
				oFacePx = oOccFaces.Item(i)
				Dim oAttributeSet As AttributeSet
				For Each oAttributeSet In oNativeFaces(i).AttributeSets
					Dim oNewAttSet As AttributeSet
					oNewAttSet = oFacePx.AttributeSets.Add(oAttributeSet.Name)
					Dim oAttribute As Inventor.Attribute
					For Each oAttribute In oAttributeSet
						oNewAttSet.Add(oAttribute.Name, oAttribute.ValueType, oAttribute.Value)
					Next
				Next

			Next

		End Sub
		Private Sub m_sampleButton2_OnExecute(Context As NameValueMap) Handles m_sampleButton2.OnExecute
			'CreateRibbonButtonPopup()
			'PrintRibbon()
			'AddiParts()
			'RetrieveFaceFromFactory()
			'FindOccurrences()
			'PopulateIparts
			'defaultTest()
			'MsgBox("Button was clicked.Huzzah!")
			Dim testForm As New Form1
			testForm.Show()
		End Sub
		'Ms
		' Sample handler for the button.
		'Private Sub m_sampleButton_OnExecute(Context As NameValueMap) Handles m_sampleButton.OnExecute
		'	Dim name As String = InputBox("What is the File Name", "Part File Name", "Sample Part")
		'	If name <> String.Empty AndAlso name <> "Sample Part" Then
		'		Dim newPartDoc As PartDocument = g_inventorApplication.Documents.Add(DocumentTypeEnum.kPartDocumentObject)
		'		newPartDoc.SaveAs("H:\Inventor\Lessons\Demo\DemoParts\" & name & ".ipt", False)
		'	End If

		'	'MsgBox("Button was clicked.Huzzah!")
		'End Sub
#End Region

	End Class
End Namespace


Public Module Globals
	' Inventor application object.
	Public g_inventorApplication As Inventor.Application

#Region "Function to get the add-in client ID."
	' This function uses reflection to get the GuidAttribute associated with the add-in.
	Public Function AddInClientID() As String
		Dim guid As String = ""
		Try
			Dim t As Type = GetType(InventorAddInDemo1.StandardAddInServer)
			Dim customAttributes() As Object = t.GetCustomAttributes(GetType(GuidAttribute), False)
			Dim guidAttribute As GuidAttribute = CType(customAttributes(0), GuidAttribute)
			guid = "{" + guidAttribute.Value.ToString() + "}"
		Catch
		End Try

		Return guid
	End Function
#End Region

#Region "hWnd Wrapper Class"
	' This class is used to wrap a Win32 hWnd as a .Net IWind32Window class.
	' This is primarily used for parenting a dialog to the Inventor window.
	'
	' For example:
	' myForm.Show(New WindowWrapper(g_inventorApplication.MainFrameHWND))
	'
	Public Class WindowWrapper
		Implements System.Windows.Forms.IWin32Window
		Public Sub New(ByVal handle As IntPtr)
			_hwnd = handle
		End Sub

		Public ReadOnly Property Handle() As IntPtr _
		  Implements System.Windows.Forms.IWin32Window.Handle
			Get
				Return _hwnd
			End Get
		End Property

		Private _hwnd As IntPtr
	End Class
#End Region

#Region "Image Converter"
	' Class used to convert bitmaps and icons from their .Net native types into
	' an IPictureDisp object which is what the Inventor API requires. A typical
	' usage is shown below where MyIcon is a bitmap or icon that's available
	' as a resource of the project.
	'
	' Dim smallIcon As stdole.IPictureDisp = PictureDispConverter.ToIPictureDisp(My.Resources.MyIcon)

	Public NotInheritable Class PictureDispConverter
		<DllImport("OleAut32.dll", EntryPoint:="OleCreatePictureIndirect", ExactSpelling:=True, PreserveSig:=False)> _
		Private Shared Function OleCreatePictureIndirect( _
			<MarshalAs(UnmanagedType.AsAny)> ByVal picdesc As Object, _
			ByRef iid As Guid, _
			<MarshalAs(UnmanagedType.Bool)> ByVal fOwn As Boolean) As stdole.IPictureDisp
		End Function

		Shared iPictureDispGuid As Guid = GetType(stdole.IPictureDisp).GUID

		Private NotInheritable Class PICTDESC
			Private Sub New()
			End Sub

			'Picture Types
			Public Const PICTYPE_BITMAP As Short = 1
			Public Const PICTYPE_ICON As Short = 3

			<StructLayout(LayoutKind.Sequential)> _
			Public Class Icon
				Friend cbSizeOfStruct As Integer = Marshal.SizeOf(GetType(PICTDESC.Icon))
				Friend picType As Integer = PICTDESC.PICTYPE_ICON
				Friend hicon As IntPtr = IntPtr.Zero
				Friend unused1 As Integer
				Friend unused2 As Integer

				Friend Sub New(ByVal icon As System.Drawing.Icon)
					Me.hicon = icon.ToBitmap().GetHicon()
				End Sub
			End Class

			<StructLayout(LayoutKind.Sequential)> _
			Public Class Bitmap
				Friend cbSizeOfStruct As Integer = Marshal.SizeOf(GetType(PICTDESC.Bitmap))
				Friend picType As Integer = PICTDESC.PICTYPE_BITMAP
				Friend hbitmap As IntPtr = IntPtr.Zero
				Friend hpal As IntPtr = IntPtr.Zero
				Friend unused As Integer

				Friend Sub New(ByVal bitmap As System.Drawing.Bitmap)
					Me.hbitmap = bitmap.GetHbitmap()
				End Sub
			End Class
		End Class

		Public Shared Function ToIPictureDisp(ByVal icon As System.Drawing.Icon) As stdole.IPictureDisp
			Dim pictIcon As New PICTDESC.Icon(icon)
			Return OleCreatePictureIndirect(pictIcon, iPictureDispGuid, True)
		End Function

		Public Shared Function ToIPictureDisp(ByVal bmp As System.Drawing.Bitmap) As stdole.IPictureDisp
			Dim pictBmp As New PICTDESC.Bitmap(bmp)
			Return OleCreatePictureIndirect(pictBmp, iPictureDispGuid, True)
		End Function
	End Class
#End Region

End Module
