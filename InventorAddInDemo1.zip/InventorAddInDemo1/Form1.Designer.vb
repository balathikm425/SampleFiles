﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.cboProfileID = New System.Windows.Forms.ComboBox()
		Me.cmdClose = New System.Windows.Forms.Button()
		Me.btnUpdate = New System.Windows.Forms.Button()
		Me.lblProfileID = New System.Windows.Forms.Label()
		Me.grpBuilding = New System.Windows.Forms.GroupBox()
		Me.cboChannleID = New System.Windows.Forms.ComboBox()
		Me.lblChannelID = New System.Windows.Forms.Label()
		Me.txtRoofPitch = New System.Windows.Forms.TextBox()
		Me.lblRoofPitch = New System.Windows.Forms.Label()
		Me.txtHeight = New System.Windows.Forms.TextBox()
		Me.lblHeight = New System.Windows.Forms.Label()
		Me.txtLength = New System.Windows.Forms.TextBox()
		Me.lblLength = New System.Windows.Forms.Label()
		Me.txtSpan = New System.Windows.Forms.TextBox()
		Me.lblSpan = New System.Windows.Forms.Label()
		Me.grpChannel = New System.Windows.Forms.GroupBox()
		Me.cboLIPLength = New System.Windows.Forms.ComboBox()
		Me.cbochannelThickness = New System.Windows.Forms.ComboBox()
		Me.lblLIP = New System.Windows.Forms.Label()
		Me.txtChannelLength = New System.Windows.Forms.TextBox()
		Me.lblChannelLength = New System.Windows.Forms.Label()
		Me.txtChannelWidth2 = New System.Windows.Forms.TextBox()
		Me.lblChannelWidth2 = New System.Windows.Forms.Label()
		Me.lblThickness = New System.Windows.Forms.Label()
		Me.txtChannelWidth1 = New System.Windows.Forms.TextBox()
		Me.lblChannelWidth1 = New System.Windows.Forms.Label()
		Me.txtChannelHeight = New System.Windows.Forms.TextBox()
		Me.lblChannelHeight = New System.Windows.Forms.Label()
		Me.txtChannelID = New System.Windows.Forms.TextBox()
		Me.lblChannelSecName = New System.Windows.Forms.Label()
		Me.grpBuilding.SuspendLayout()
		Me.grpChannel.SuspendLayout()
		Me.SuspendLayout()
		'
		'cboProfileID
		'
		Me.cboProfileID.FormattingEnabled = True
		Me.cboProfileID.Location = New System.Drawing.Point(124, 32)
		Me.cboProfileID.Name = "cboProfileID"
		Me.cboProfileID.Size = New System.Drawing.Size(121, 21)
		Me.cboProfileID.TabIndex = 0
		'
		'cmdClose
		'
		Me.cmdClose.Location = New System.Drawing.Point(694, 361)
		Me.cmdClose.Name = "cmdClose"
		Me.cmdClose.Size = New System.Drawing.Size(75, 23)
		Me.cmdClose.TabIndex = 1
		Me.cmdClose.Text = "Close"
		Me.cmdClose.UseVisualStyleBackColor = True
		'
		'btnUpdate
		'
		Me.btnUpdate.Location = New System.Drawing.Point(74, 361)
		Me.btnUpdate.Name = "btnUpdate"
		Me.btnUpdate.Size = New System.Drawing.Size(75, 23)
		Me.btnUpdate.TabIndex = 2
		Me.btnUpdate.Text = "Update"
		Me.btnUpdate.UseVisualStyleBackColor = True
		'
		'lblProfileID
		'
		Me.lblProfileID.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.lblProfileID.AutoSize = True
		Me.lblProfileID.Location = New System.Drawing.Point(65, 35)
		Me.lblProfileID.Name = "lblProfileID"
		Me.lblProfileID.Size = New System.Drawing.Size(53, 13)
		Me.lblProfileID.TabIndex = 3
		Me.lblProfileID.Text = "Profile ID:"
		'
		'grpBuilding
		'
		Me.grpBuilding.Controls.Add(Me.cboChannleID)
		Me.grpBuilding.Controls.Add(Me.lblChannelID)
		Me.grpBuilding.Controls.Add(Me.txtRoofPitch)
		Me.grpBuilding.Controls.Add(Me.lblRoofPitch)
		Me.grpBuilding.Controls.Add(Me.txtHeight)
		Me.grpBuilding.Controls.Add(Me.lblHeight)
		Me.grpBuilding.Controls.Add(Me.txtLength)
		Me.grpBuilding.Controls.Add(Me.lblLength)
		Me.grpBuilding.Controls.Add(Me.txtSpan)
		Me.grpBuilding.Controls.Add(Me.lblSpan)
		Me.grpBuilding.Location = New System.Drawing.Point(74, 71)
		Me.grpBuilding.Name = "grpBuilding"
		Me.grpBuilding.Size = New System.Drawing.Size(231, 221)
		Me.grpBuilding.TabIndex = 4
		Me.grpBuilding.TabStop = False
		Me.grpBuilding.Text = "Building Data"
		'
		'cboChannleID
		'
		Me.cboChannleID.FormattingEnabled = True
		Me.cboChannleID.Location = New System.Drawing.Point(71, 188)
		Me.cboChannleID.Name = "cboChannleID"
		Me.cboChannleID.Size = New System.Drawing.Size(121, 21)
		Me.cboChannleID.TabIndex = 10
		'
		'lblChannelID
		'
		Me.lblChannelID.AutoSize = True
		Me.lblChannelID.Location = New System.Drawing.Point(6, 191)
		Me.lblChannelID.Name = "lblChannelID"
		Me.lblChannelID.Size = New System.Drawing.Size(60, 13)
		Me.lblChannelID.TabIndex = 8
		Me.lblChannelID.Text = "Channel ID"
		'
		'txtRoofPitch
		'
		Me.txtRoofPitch.Location = New System.Drawing.Point(71, 146)
		Me.txtRoofPitch.Name = "txtRoofPitch"
		Me.txtRoofPitch.Size = New System.Drawing.Size(121, 20)
		Me.txtRoofPitch.TabIndex = 7
		'
		'lblRoofPitch
		'
		Me.lblRoofPitch.AutoSize = True
		Me.lblRoofPitch.Location = New System.Drawing.Point(9, 153)
		Me.lblRoofPitch.Name = "lblRoofPitch"
		Me.lblRoofPitch.Size = New System.Drawing.Size(57, 13)
		Me.lblRoofPitch.TabIndex = 6
		Me.lblRoofPitch.Text = "Roof Pitch"
		'
		'txtHeight
		'
		Me.txtHeight.Location = New System.Drawing.Point(71, 62)
		Me.txtHeight.Name = "txtHeight"
		Me.txtHeight.Size = New System.Drawing.Size(119, 20)
		Me.txtHeight.TabIndex = 5
		'
		'lblHeight
		'
		Me.lblHeight.AutoSize = True
		Me.lblHeight.Location = New System.Drawing.Point(28, 67)
		Me.lblHeight.Name = "lblHeight"
		Me.lblHeight.Size = New System.Drawing.Size(38, 13)
		Me.lblHeight.TabIndex = 4
		Me.lblHeight.Text = "Height"
		'
		'txtLength
		'
		Me.txtLength.Location = New System.Drawing.Point(71, 104)
		Me.txtLength.Name = "txtLength"
		Me.txtLength.Size = New System.Drawing.Size(121, 20)
		Me.txtLength.TabIndex = 3
		'
		'lblLength
		'
		Me.lblLength.AutoSize = True
		Me.lblLength.Location = New System.Drawing.Point(26, 110)
		Me.lblLength.Name = "lblLength"
		Me.lblLength.Size = New System.Drawing.Size(40, 13)
		Me.lblLength.TabIndex = 2
		Me.lblLength.Text = "Length"
		'
		'txtSpan
		'
		Me.txtSpan.Location = New System.Drawing.Point(71, 20)
		Me.txtSpan.Name = "txtSpan"
		Me.txtSpan.Size = New System.Drawing.Size(121, 20)
		Me.txtSpan.TabIndex = 1
		'
		'lblSpan
		'
		Me.lblSpan.AutoSize = True
		Me.lblSpan.Location = New System.Drawing.Point(34, 24)
		Me.lblSpan.Name = "lblSpan"
		Me.lblSpan.Size = New System.Drawing.Size(32, 13)
		Me.lblSpan.TabIndex = 0
		Me.lblSpan.Text = "Span"
		'
		'grpChannel
		'
		Me.grpChannel.Controls.Add(Me.cboLIPLength)
		Me.grpChannel.Controls.Add(Me.cbochannelThickness)
		Me.grpChannel.Controls.Add(Me.lblLIP)
		Me.grpChannel.Controls.Add(Me.txtChannelLength)
		Me.grpChannel.Controls.Add(Me.lblChannelLength)
		Me.grpChannel.Controls.Add(Me.txtChannelWidth2)
		Me.grpChannel.Controls.Add(Me.lblChannelWidth2)
		Me.grpChannel.Controls.Add(Me.lblThickness)
		Me.grpChannel.Controls.Add(Me.txtChannelWidth1)
		Me.grpChannel.Controls.Add(Me.lblChannelWidth1)
		Me.grpChannel.Controls.Add(Me.txtChannelHeight)
		Me.grpChannel.Controls.Add(Me.lblChannelHeight)
		Me.grpChannel.Controls.Add(Me.txtChannelID)
		Me.grpChannel.Controls.Add(Me.lblChannelSecName)
		Me.grpChannel.Location = New System.Drawing.Point(328, 71)
		Me.grpChannel.Name = "grpChannel"
		Me.grpChannel.Size = New System.Drawing.Size(441, 260)
		Me.grpChannel.TabIndex = 5
		Me.grpChannel.TabStop = False
		Me.grpChannel.Text = "Channel Selection"
		'
		'cboLIPLength
		'
		Me.cboLIPLength.FormattingEnabled = True
		Me.cboLIPLength.Items.AddRange(New Object() {"", "12.5", "13.5", "14.5", "15.5", "16.5", "18.5", "19", "20.5", "21", "27.5", "30", "31.5", ""})
		Me.cboLIPLength.Location = New System.Drawing.Point(69, 226)
		Me.cboLIPLength.Name = "cboLIPLength"
		Me.cboLIPLength.Size = New System.Drawing.Size(121, 21)
		Me.cboLIPLength.TabIndex = 18
		'
		'cbochannelThickness
		'
		Me.cbochannelThickness.FormattingEnabled = True
		Me.cbochannelThickness.Items.AddRange(New Object() {"", "1", "1.2", "1.5", "1.9", "2.4", "3"})
		Me.cbochannelThickness.Location = New System.Drawing.Point(69, 143)
		Me.cbochannelThickness.Name = "cbochannelThickness"
		Me.cbochannelThickness.Size = New System.Drawing.Size(121, 21)
		Me.cbochannelThickness.TabIndex = 17
		'
		'lblLIP
		'
		Me.lblLIP.AutoSize = True
		Me.lblLIP.Location = New System.Drawing.Point(39, 229)
		Me.lblLIP.Name = "lblLIP"
		Me.lblLIP.Size = New System.Drawing.Size(24, 13)
		Me.lblLIP.TabIndex = 15
		Me.lblLIP.Text = "Lip:"
		'
		'txtChannelLength
		'
		Me.txtChannelLength.Location = New System.Drawing.Point(69, 185)
		Me.txtChannelLength.Name = "txtChannelLength"
		Me.txtChannelLength.Size = New System.Drawing.Size(121, 20)
		Me.txtChannelLength.TabIndex = 14
		'
		'lblChannelLength
		'
		Me.lblChannelLength.AutoSize = True
		Me.lblChannelLength.Location = New System.Drawing.Point(20, 191)
		Me.lblChannelLength.Name = "lblChannelLength"
		Me.lblChannelLength.Size = New System.Drawing.Size(43, 13)
		Me.lblChannelLength.TabIndex = 13
		Me.lblChannelLength.Text = "Length:"
		'
		'txtChannelWidth2
		'
		Me.txtChannelWidth2.Location = New System.Drawing.Point(259, 102)
		Me.txtChannelWidth2.Name = "txtChannelWidth2"
		Me.txtChannelWidth2.Size = New System.Drawing.Size(119, 20)
		Me.txtChannelWidth2.TabIndex = 12
		'
		'lblChannelWidth2
		'
		Me.lblChannelWidth2.AutoSize = True
		Me.lblChannelWidth2.Location = New System.Drawing.Point(206, 105)
		Me.lblChannelWidth2.Name = "lblChannelWidth2"
		Me.lblChannelWidth2.Size = New System.Drawing.Size(47, 13)
		Me.lblChannelWidth2.TabIndex = 11
		Me.lblChannelWidth2.Text = "Width 2:"
		'
		'lblThickness
		'
		Me.lblThickness.AutoSize = True
		Me.lblThickness.Location = New System.Drawing.Point(6, 146)
		Me.lblThickness.Name = "lblThickness"
		Me.lblThickness.Size = New System.Drawing.Size(59, 13)
		Me.lblThickness.TabIndex = 6
		Me.lblThickness.Text = "Thickness:"
		'
		'txtChannelWidth1
		'
		Me.txtChannelWidth1.Location = New System.Drawing.Point(71, 102)
		Me.txtChannelWidth1.Name = "txtChannelWidth1"
		Me.txtChannelWidth1.Size = New System.Drawing.Size(119, 20)
		Me.txtChannelWidth1.TabIndex = 5
		'
		'lblChannelWidth1
		'
		Me.lblChannelWidth1.AutoSize = True
		Me.lblChannelWidth1.Location = New System.Drawing.Point(18, 107)
		Me.lblChannelWidth1.Name = "lblChannelWidth1"
		Me.lblChannelWidth1.Size = New System.Drawing.Size(47, 13)
		Me.lblChannelWidth1.TabIndex = 4
		Me.lblChannelWidth1.Text = "Width 1:"
		'
		'txtChannelHeight
		'
		Me.txtChannelHeight.Location = New System.Drawing.Point(71, 61)
		Me.txtChannelHeight.Name = "txtChannelHeight"
		Me.txtChannelHeight.Size = New System.Drawing.Size(121, 20)
		Me.txtChannelHeight.TabIndex = 3
		'
		'lblChannelHeight
		'
		Me.lblChannelHeight.AutoSize = True
		Me.lblChannelHeight.Location = New System.Drawing.Point(24, 64)
		Me.lblChannelHeight.Name = "lblChannelHeight"
		Me.lblChannelHeight.Size = New System.Drawing.Size(41, 13)
		Me.lblChannelHeight.TabIndex = 2
		Me.lblChannelHeight.Text = "Height:"
		'
		'txtChannelID
		'
		Me.txtChannelID.Location = New System.Drawing.Point(71, 20)
		Me.txtChannelID.Name = "txtChannelID"
		Me.txtChannelID.Size = New System.Drawing.Size(121, 20)
		Me.txtChannelID.TabIndex = 1
		'
		'lblChannelSecName
		'
		Me.lblChannelSecName.AutoSize = True
		Me.lblChannelSecName.Location = New System.Drawing.Point(5, 24)
		Me.lblChannelSecName.Name = "lblChannelSecName"
		Me.lblChannelSecName.Size = New System.Drawing.Size(60, 13)
		Me.lblChannelSecName.TabIndex = 0
		Me.lblChannelSecName.Text = "Channel ID"
		'
		'Form1
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(800, 422)
		Me.Controls.Add(Me.grpChannel)
		Me.Controls.Add(Me.grpBuilding)
		Me.Controls.Add(Me.lblProfileID)
		Me.Controls.Add(Me.btnUpdate)
		Me.Controls.Add(Me.cmdClose)
		Me.Controls.Add(Me.cboProfileID)
		Me.Name = "Form1"
		Me.Text = "Form1"
		Me.grpBuilding.ResumeLayout(False)
		Me.grpBuilding.PerformLayout()
		Me.grpChannel.ResumeLayout(False)
		Me.grpChannel.PerformLayout()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub

	Friend WithEvents cboProfileID As Windows.Forms.ComboBox
	Friend WithEvents cmdClose As Windows.Forms.Button
	Friend WithEvents btnUpdate As Windows.Forms.Button
	Friend WithEvents lblProfileID As Windows.Forms.Label
	Friend WithEvents grpBuilding As Windows.Forms.GroupBox
	Friend WithEvents txtRoofPitch As Windows.Forms.TextBox
	Friend WithEvents lblRoofPitch As Windows.Forms.Label
	Friend WithEvents txtHeight As Windows.Forms.TextBox
	Friend WithEvents lblHeight As Windows.Forms.Label
	Friend WithEvents txtLength As Windows.Forms.TextBox
	Friend WithEvents lblLength As Windows.Forms.Label
	Friend WithEvents txtSpan As Windows.Forms.TextBox
	Friend WithEvents lblSpan As Windows.Forms.Label
	Friend WithEvents lblChannelID As Windows.Forms.Label
	Friend WithEvents cboChannleID As Windows.Forms.ComboBox
	Friend WithEvents grpChannel As Windows.Forms.GroupBox
	Friend WithEvents lblThickness As Windows.Forms.Label
	Friend WithEvents txtChannelWidth1 As Windows.Forms.TextBox
	Friend WithEvents lblChannelWidth1 As Windows.Forms.Label
	Friend WithEvents txtChannelHeight As Windows.Forms.TextBox
	Friend WithEvents lblChannelHeight As Windows.Forms.Label
	Friend WithEvents txtChannelID As Windows.Forms.TextBox
	Friend WithEvents lblChannelSecName As Windows.Forms.Label
	Friend WithEvents txtChannelWidth2 As Windows.Forms.TextBox
	Friend WithEvents lblChannelWidth2 As Windows.Forms.Label
	Friend WithEvents cboLIPLength As Windows.Forms.ComboBox
	Friend WithEvents cbochannelThickness As Windows.Forms.ComboBox
	Friend WithEvents lblLIP As Windows.Forms.Label
	Friend WithEvents txtChannelLength As Windows.Forms.TextBox
	Friend WithEvents lblChannelLength As Windows.Forms.Label
End Class
